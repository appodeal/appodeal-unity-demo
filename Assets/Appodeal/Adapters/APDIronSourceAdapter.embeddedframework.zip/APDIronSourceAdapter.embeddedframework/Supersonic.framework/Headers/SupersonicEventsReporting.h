//
//  SupersonicEventsReporting.h
//  Supersonic
//
//  Created by Adi Oz on 7/22/15.
//  Copyright (c) 2015 Supersonic. All rights reserved.
//

#ifndef Supersonic_SupersonicEventsReporting_h
#define Supersonic_SupersonicEventsReporting_h

#import <Foundation/Foundation.h>

@interface SupersonicEventsReporting : NSObject

+(void) reportAppStarted;

@end

#endif


