//
//  SOMANativeAdAppWallLayouter.h
//  iSoma
//
//  Created by Aman Shaikh on 11.12.15.
//  Copyright © 2015 Smaato Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SOMANativeAdLayouter.h"


@interface SOMANativeAdAppWallLayouter : NSObject<SOMANativeAdLayouter>

@end
