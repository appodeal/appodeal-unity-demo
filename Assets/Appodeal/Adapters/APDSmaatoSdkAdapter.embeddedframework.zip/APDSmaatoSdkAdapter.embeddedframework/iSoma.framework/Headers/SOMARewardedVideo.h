//
//  SOMARewardedVideo.h
//  iSoma
//
//  Created by Aman Shaikh on 20.09.16.
//  Copyright © 2016 Smaato Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SOMAInterstitialVideoAdView.h"

@interface SOMARewardedVideo : SOMAInterstitialVideoAdView
@end
