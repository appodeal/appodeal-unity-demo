//
//  SOMAInterstitialView.h
//  iSoma
//
//  Created by Aman Shaikh on 01/07/14.
//  Copyright (c) 2014 Smaato Inc. All rights reserved.
//

#import "SOMAAdView.h"

@interface SOMAInterstitialAdView : SOMAAdView
@property UIInterfaceOrientation initialOrientation;
- (void)show:(UIViewController*)rootViewController;
@end
