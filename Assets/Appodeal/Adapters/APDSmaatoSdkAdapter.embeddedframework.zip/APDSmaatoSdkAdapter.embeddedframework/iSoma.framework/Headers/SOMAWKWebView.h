//
//  SOMAUIWebView.h
//  iSoma
//
//  Created by Aman Shaikh on 17/03/2017.
//  Copyright © 2017 Smaato Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface SOMAWKWebView : WKWebView
@property BOOL isTouched;
@property BOOL isTouchedOnced;
@end

