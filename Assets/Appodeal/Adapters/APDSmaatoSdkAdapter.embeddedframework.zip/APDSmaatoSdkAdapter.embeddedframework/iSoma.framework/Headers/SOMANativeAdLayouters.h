//
//  SOMANativeAdLayouters.h
//  iSoma
//
//  Created by Aman Shaikh on 09.12.15.
//  Copyright © 2015 Smaato Inc. All rights reserved.
//

#ifndef SOMANativeAdLayouters_h
#define SOMANativeAdLayouters_h

#import "SOMANativeAdContentWallLayouter.h"
#import "SOMANativeAdAppWallLayouter.h"
#import "SOMANativeAdNewsFeedLayouter.h"
#import "SOMANativeAdContentStreamLayouter.h"
#import "SOMANativeAdChatListLayouter.h"
#import "SOMANativeAdCarouselLayouter.h"

#endif /* SOMANativeAdLayouters_h */
