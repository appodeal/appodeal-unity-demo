//
//  SOMANativeAdContentWallLayouter.h
//  iSoma
//
//  Created by Aman Shaikh on 09.12.15.
//  Copyright © 2015 Smaato Inc. All rights reserved.
//

#import "SOMANativeAdLayouter.h"

@interface SOMANativeAdContentWallLayouter:NSObject<SOMANativeAdLayouter>

@end
