//
//  SOMANativeAdCarouselLayouter.h
//  iSoma
//
//  Created by Aman Shaikh on 06.01.16.
//  Copyright © 2016 Smaato Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SOMANativeAdLayouter.h"

@interface SOMANativeAdCarouselLayouter : NSObject<SOMANativeAdLayouter>

@end
