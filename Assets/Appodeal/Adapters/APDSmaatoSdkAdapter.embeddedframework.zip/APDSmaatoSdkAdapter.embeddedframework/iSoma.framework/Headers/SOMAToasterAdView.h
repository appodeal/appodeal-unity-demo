//
//  SOMAToasterAdView.h
//  iSoma
//
//  Created by Aman Shaikh on 02/07/14.
//  Copyright (c) 2014 Smaato Inc. All rights reserved.
//

#import "SOMAAdView.h"

@interface SOMAToasterAdView : SOMAAdView

@end
