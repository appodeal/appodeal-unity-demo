//
//  SOMANativeAdNewsFeedLayouter.h
//  iSoma
//
//  Created by Aman Shaikh on 18.12.15.
//  Copyright © 2015 Smaato Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SOMANativeAdLayouter.h"

@interface SOMANativeAdNewsFeedLayouter : NSObject<SOMANativeAdLayouter>

@end
