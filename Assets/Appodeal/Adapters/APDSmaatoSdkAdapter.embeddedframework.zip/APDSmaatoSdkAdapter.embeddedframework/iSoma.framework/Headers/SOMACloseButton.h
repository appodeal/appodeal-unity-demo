//
//  SOMACloseButton.h
//  iSoma
//
//  Created by Aman Shaikh on 30/06/14.
//  Copyright (c) 2014 Smaato Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SOMACloseButton : UIButton
@property BOOL onlyCross;
@property UIColor* crossColor;

@end
