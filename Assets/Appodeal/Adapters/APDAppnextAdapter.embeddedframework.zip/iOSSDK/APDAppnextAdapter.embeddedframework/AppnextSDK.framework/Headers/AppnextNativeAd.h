//
//  AppnextNativeAd.h
//  AppnextNativeAdsSDK
//
//  Created by Eran Mausner on 16/08/2016.
//  Copyright © 2016 Appnext. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppnextSDK/AppnextAd.h>

@interface AppnextNativeAd : AppnextAd

@end
