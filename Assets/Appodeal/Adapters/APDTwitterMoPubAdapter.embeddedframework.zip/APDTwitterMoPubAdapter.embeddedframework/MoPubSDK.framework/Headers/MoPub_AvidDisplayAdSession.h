//
//  AvidDisplayAdSession.h
//  AppVerificationLibrary
//
//  Created by Daria Sukhonosova on 05/04/16.
//  Copyright © 2016 Integral. All rights reserved.
//

#import "MoPub_AbstractAvidAdSession.h"

@interface MoPub_AvidDisplayAdSession : MoPub_AbstractAvidAdSession

@end
