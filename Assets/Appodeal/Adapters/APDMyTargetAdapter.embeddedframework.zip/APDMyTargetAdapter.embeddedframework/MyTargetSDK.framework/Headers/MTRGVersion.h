//
//  MTRGVersion.h
//  myTargetSDK 5.0.1
//
//  Created by Andrey Seredkin on 29.06.17.
//  Copyright © 2017 Mail.ru Group. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MTRGVersion : NSObject

+ (NSString *)currentVersion;

@end

NS_ASSUME_NONNULL_END
